package com.example.lab1sukhmanpreetsingh;

public record albums() {
}albums(int artistID, String songName, String albumName, int selling_price) {
}

