package com.example.lab1sukhmanpreetsingh;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {

    @FXML
    private TableView<albums> tableView;
    @FXML
    private TableColumn<albums, Integer> artistID;
    @FXML
    private TableColumn<albums, String> songName;
    @FXML
    private TableColumn<albums, String> albumName;
    @FXML
    private TableColumn<albums, Integer> selling_price;
    ObservableList<albums> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        artistID.setCellValueFactory(new
                PropertyValueFactory<albums, Integer>("artistID"));
        songName.setCellValueFactory(new
                PropertyValueFactory<albums, String>("songName"));
        albumName.setCellValueFactory(new
                PropertyValueFactory<albums, String>("albumName"));
        selling_price.setCellValueFactory(new
                PropertyValueFactory<albums, Integer>("selling_price"));
        tableView.setItems(list);
    }

    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }
    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab1programming";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM sukhman";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int songID = resultSet.getInt("songID");
                String songName = resultSet.getString("songName");
                String albumName = resultSet.getString("albumName");
                int selling_price = resultSet.getInt("selling_price");
                tableView.getItems().add(new albums(songID, songName, albumName,
                        selling_price));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



}

