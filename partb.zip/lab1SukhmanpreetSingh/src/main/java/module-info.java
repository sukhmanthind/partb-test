module com.example.lab1sukhmanpreetsingh {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.lab1sukhmanpreetsingh to javafx.fxml;
    exports com.example.lab1sukhmanpreetsingh;
}