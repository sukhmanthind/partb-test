module com.example.partb {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.partb to javafx.fxml;
    exports com.example.partb;
}