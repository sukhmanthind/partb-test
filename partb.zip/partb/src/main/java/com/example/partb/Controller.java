package com.example.partb;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label messageLabel;

    private int failedAttempts = 0;
    private final int MAX_ATTEMPTS = 5;

    @FXML
    public void onLoginButtonClick() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please Provide Username or Password");
        } else if (failedAttempts >= MAX_ATTEMPTS) {
            messageLabel.setText("Sorry, Your Account is Locked!!!");
        } else if (username.equals("sukhmanpreet") && password.equals("456")) {
            messageLabel.setText("Success!!!");
            failedAttempts = 0; // reset attempts on success
        } else {
            failedAttempts++;
            messageLabel.setText("Sorry, Invalid Username or Password");
            if (failedAttempts >= MAX_ATTEMPTS) {
                messageLabel.setText("Sorry, Your Account is Locked!!!");
            }
        }
    }
}